import { Component, computed, inject, linkedSignal, signal } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import {
  AbstractControl,
  NonNullableFormBuilder,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { TranslocoPipe, TranslocoService } from '@jsverse/transloco';
import { ColDef } from 'ag-grid-community';
import { ButtonModule } from 'primeng/button';
import { Dialog } from 'primeng/dialog';
import { InputText } from 'primeng/inputtext';
import { ApiError } from '../../core/api/mock-api';
import {
  PlatformService,
  generatePassword,
  organizationUrl,
} from '../../core/data/platform.service';
import { LanguageService } from '../../core/i18n/language.service';
import { Organization } from '../../core/models';
import { NotifyService } from '../../core/notify/notify.service';
import { formatDateTime } from '../../shared/format/format';
import { dotCell } from '../../shared/grid/cells';
import { DataGrid } from '../../shared/grid/data-grid';
import {
  CredentialRow,
  CredentialsDialog,
} from '../../shared/ui/credentials-dialog/credentials-dialog';
import { Icon } from '../../shared/ui/icon/icon';
import { HotelFields, hotelDraft, hotelGroup } from './hotel-fields';

/** Поддомен: 3–30 символов, строчная латиница, цифры и «-» в середине (как на сервере). */
const CODE_RE = /^[a-z0-9](?:[a-z0-9-]{1,28}[a-z0-9])$/;
const RESERVED = ['www', 'api', 'admin', 'app', 'static', 'mail', 'platform'];
const LOGIN_RE = /^[a-z0-9._-]{3,32}$/;

function codeValidator(c: AbstractControl<string>) {
  const v = c.value ?? '';
  return CODE_RE.test(v) && !RESERVED.includes(v) ? null : { code: true };
}

/** Платформа → «Владельцы»: таблица владельцев и форма «Новый владелец» (v1.6). */
@Component({
  selector: 'app-platform-organizations',
  imports: [
    ReactiveFormsModule,
    TranslocoPipe,
    ButtonModule,
    Dialog,
    InputText,
    DataGrid,
    CredentialsDialog,
    Icon,
    HotelFields,
  ],
  template: `
    <div class="flex flex-col gap-4 px-6 pt-5 pb-8 max-md:px-4 max-md:pt-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="m-0 text-2xl font-bold tracking-[-0.01em] max-md:text-xl">
            {{ 'platform.orgs.title' | transloco }}
          </h1>
          <p class="mt-1 mb-0 text-[13px] text-muted">{{ 'platform.orgs.subtitle' | transloco }}</p>
        </div>
        <div class="flex flex-wrap gap-2">
          <button
            pButton
            type="button"
            severity="secondary"
            [outlined]="true"
            [disabled]="!selected()"
            (click)="open(selected()!)"
          >
            <app-icon name="external" />
            <span pButtonLabel>{{ 'platform.orgs.open' | transloco }}</span>
          </button>
          <button pButton type="button" (click)="openAdd()">
            <app-icon name="plus" />
            <span pButtonLabel>{{ 'platform.orgs.add' | transloco }}</span>
          </button>
        </div>
      </div>

      <section class="overflow-hidden rounded-xl border border-line bg-white">
        <app-data-grid
          [rows]="rows()"
          [columns]="columns()"
          [loading]="res.isLoading()"
          [selectable]="true"
          [details]="false"
          [getRowId]="rowId"
          emptyText="platform.orgs.empty"
          [minWidth]="1100"
          (selection)="selected.set($event)"
          (rowDoubleClick)="open($event)"
        />
      </section>
    </div>

    <!-- Новый владелец: владелец + аккаунт владельца + первый отель -->
    <p-dialog
      [(visible)]="formOpen"
      [modal]="true"
      [draggable]="false"
      [resizable]="false"
      [header]="'platform.orgs.addTitle' | transloco"
      [style]="{ width: '640px', maxWidth: 'calc(100vw - 32px)' }"
      styleClass="hs-dialog"
      [closeAriaLabel]="'common.close' | transloco"
    >
      <form
        id="org-form"
        class="flex flex-col gap-5"
        [formGroup]="form"
        (ngSubmit)="save()"
        novalidate
      >
        <fieldset class="m-0 flex flex-col gap-3 border-0 p-0">
          <legend class="mb-2 text-[15px] font-semibold">
            {{ 'platform.orgs.partOrg' | transloco }}
          </legend>
          <div class="grid grid-cols-2 gap-4 max-sm:grid-cols-1">
            <div class="field">
              <label for="o-code" class="field-label"
                >{{ 'platform.orgs.code' | transloco }} <span class="req">*</span></label
              >
              <input
                id="o-code"
                pInputText
                formControlName="code"
                autocomplete="off"
                placeholder="grand"
                [invalid]="codeBad()"
                [attr.aria-invalid]="codeBad()"
                aria-describedby="o-code-hint"
              />
              <span id="o-code-hint" class="hint" [class.text-danger]="codeBad()">{{
                (serverErrors()['code'] === 'exists'
                  ? 'errors.organizations.exists'
                  : 'platform.orgs.codeHint'
                ) | transloco
              }}</span>
            </div>
            <div class="field">
              <label for="o-name" class="field-label"
                >{{ 'platform.orgs.name' | transloco }} <span class="req">*</span></label
              >
              <input
                id="o-name"
                pInputText
                formControlName="name"
                placeholder="Grand Group"
                [invalid]="bad(form.controls.name)"
                [attr.aria-invalid]="bad(form.controls.name)"
              />
            </div>
          </div>
          @if (form.controls.code.value && !codeBad()) {
            <p class="m-0 text-xs text-muted">
              {{ 'platform.orgs.link' | transloco }}: <span class="font-mono">{{ link() }}</span>
            </p>
          }
        </fieldset>

        <fieldset class="m-0 flex flex-col gap-3 border-0 p-0" [formGroup]="form.controls.owner">
          <legend class="mb-2 text-[15px] font-semibold">
            {{ 'platform.orgs.partOwner' | transloco }}
          </legend>
          <div class="grid grid-cols-2 gap-4 max-sm:grid-cols-1">
            <div class="field">
              <label for="ow-name" class="field-label"
                >{{ 'platform.owner.name' | transloco }} <span class="req">*</span></label
              >
              <input
                id="ow-name"
                pInputText
                formControlName="name"
                [invalid]="bad(form.controls.owner.controls.name)"
                [attr.aria-invalid]="bad(form.controls.owner.controls.name)"
              />
            </div>
            <div class="field">
              <label for="ow-phone" class="field-label">{{
                'platform.owner.phone' | transloco
              }}</label>
              <input
                id="ow-phone"
                pInputText
                type="tel"
                formControlName="phone"
                placeholder="+998 __ ___ __ __"
              />
            </div>
            <div class="field">
              <label for="ow-login" class="field-label"
                >{{ 'platform.owner.login' | transloco }} <span class="req">*</span></label
              >
              <input
                id="ow-login"
                pInputText
                formControlName="login"
                autocomplete="off"
                [invalid]="loginBad()"
                [attr.aria-invalid]="loginBad()"
                aria-describedby="ow-login-hint"
              />
              <span id="ow-login-hint" class="hint" [class.text-danger]="loginBad()">{{
                (serverErrors()['login'] === 'taken'
                  ? 'errors.users.loginTaken'
                  : 'users.form.loginHint'
                ) | transloco
              }}</span>
            </div>
            <div class="field">
              <label for="ow-pass" class="field-label"
                >{{ 'platform.owner.password' | transloco }} <span class="req">*</span></label
              >
              <div class="flex gap-2">
                <input
                  id="ow-pass"
                  pInputText
                  formControlName="password"
                  autocomplete="new-password"
                  class="min-w-0 flex-1 font-mono"
                  [invalid]="bad(form.controls.owner.controls.password)"
                  [attr.aria-invalid]="bad(form.controls.owner.controls.password)"
                />
                <button
                  pButton
                  type="button"
                  severity="secondary"
                  [outlined]="true"
                  [attr.aria-label]="'users.form.generate' | transloco"
                  (click)="generate()"
                >
                  <app-icon name="refresh" />
                </button>
              </div>
              <span class="hint">{{ 'password.hint' | transloco }}</span>
            </div>
          </div>
        </fieldset>

        <fieldset class="m-0 flex flex-col gap-3 border-0 p-0">
          <legend class="mb-2 text-[15px] font-semibold">
            {{ 'platform.orgs.partHotel' | transloco }}
          </legend>
          <app-hotel-fields
            [group]="form.controls.hotel"
            [tried]="tried()"
            [innError]="serverErrors()['inn'] === 'invalid'"
            prefix="oh"
          />
        </fieldset>
      </form>
      <ng-template #footer>
        <button
          pButton
          type="button"
          severity="secondary"
          [outlined]="true"
          (click)="formOpen.set(false)"
        >
          <span pButtonLabel>{{ 'common.cancel' | transloco }}</span>
        </button>
        <button pButton type="submit" form="org-form" [loading]="saving()">
          @if (!saving()) {
            <app-icon name="check" />
          }
          <span pButtonLabel>{{ 'platform.orgs.create' | transloco }}</span>
        </button>
      </ng-template>
    </p-dialog>

    <!-- «Передать владельцу»: ссылка, логин и пароль один раз -->
    <app-credentials-dialog
      [(visible)]="handoverOpen"
      title="platform.handover.title"
      text="platform.handover.text"
      [params]="{ name: handoverName() }"
      [rows]="handover()"
    />
  `,
})
export class OrganizationsPage {
  private readonly api = inject(PlatformService);
  private readonly router = inject(Router);
  private readonly notify = inject(NotifyService);
  private readonly transloco = inject(TranslocoService);
  private readonly lang = inject(LanguageService);
  private readonly fb = inject(NonNullableFormBuilder);

  protected readonly res = rxResource({ stream: () => this.api.organizations() });
  protected readonly rows = linkedSignal<Organization[]>(() =>
    this.res.hasValue() ? this.res.value() : [],
  );
  protected readonly selected = signal<Organization | null>(null);
  protected readonly rowId = (p: { data: Organization }) => String(p.data.id);

  protected readonly columns = computed<ColDef<Organization>[]>(() => {
    this.lang.current();
    const t = (k: string) => this.transloco.translate(k);
    return [
      {
        field: 'code',
        headerName: t('platform.orgs.col.code'),
        flex: 1.2,
        minWidth: 200,
        cellRenderer: (p: { data: Organization }) => {
          const a = document.createElement('a');
          a.href = organizationUrl(p.data.code);
          a.target = '_blank';
          a.rel = 'noopener';
          a.textContent = `${p.data.code}`;
          a.style.cssText = 'font-weight:600';
          a.addEventListener('click', (e) => e.stopPropagation());
          return a;
        },
      },
      { field: 'name', headerName: t('platform.orgs.col.name'), flex: 1.5, minWidth: 200 },
      {
        colId: 'status',
        headerName: t('platform.orgs.col.status'),
        flex: 1,
        minWidth: 140,
        valueGetter: (p) => (p.data ? t(p.data.active ? 'users.active' : 'users.blocked') : ''),
        cellRenderer: (p: { data: Organization; value: string }) =>
          p.data.active
            ? dotCell(p.value, '#067647', '#2E8B57')
            : dotCell(p.value, '#B42318', '#D92D20'),
      },
      {
        colId: 'createdAt',
        headerName: t('platform.orgs.col.createdAt'),
        flex: 1.1,
        minWidth: 170,
        valueGetter: (p) => p.data?.createdAt ?? '',
        valueFormatter: (p) => formatDateTime(p.value),
        cellClass: 'tabular-nums text-ink-2',
      },
      {
        colId: 'hotels',
        headerName: t('platform.orgs.col.hotels'),
        flex: 2,
        minWidth: 220,
        valueGetter: (p) => p.data?.hotels.map((h) => h.name).join(', ') ?? '',
      },
      {
        colId: 'owners',
        headerName: t('platform.orgs.col.owners'),
        flex: 1.6,
        minWidth: 200,
        valueGetter: (p) => p.data?.owners.map((o) => `${o.name} (${o.login})`).join(', ') ?? '',
      },
    ];
  });

  // ----- Новый владелец -----
  protected readonly formOpen = signal(false);
  protected readonly saving = signal(false);
  protected readonly tried = signal(false);
  /** Ошибки с сервера: code = exists | invalid, login = taken, inn = invalid. */
  protected readonly serverErrors = signal<Record<string, string>>({});
  protected readonly form = this.fb.group({
    code: ['', [Validators.required, codeValidator]],
    name: ['', Validators.required],
    owner: this.fb.group({
      name: ['', Validators.required],
      login: ['', [Validators.required, Validators.pattern(LOGIN_RE)]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      phone: [''],
    }),
    hotel: hotelGroup(this.fb),
  });
  private readonly codeValue = signal('');
  protected readonly link = computed(() => organizationUrl(this.codeValue()));

  constructor() {
    this.form.controls.code.valueChanges.subscribe((v) => {
      this.codeValue.set(v);
      if (this.serverErrors()['code']) {
        this.serverErrors.update(({ code: _, ...rest }) => rest);
      }
    });
    this.form.controls.owner.controls.login.valueChanges.subscribe(() => {
      if (this.serverErrors()['login']) {
        this.serverErrors.update(({ login: _, ...rest }) => rest);
      }
    });
  }

  protected bad(c: AbstractControl): boolean {
    return this.tried() && c.invalid;
  }

  protected codeBad(): boolean {
    return this.bad(this.form.controls.code) || !!this.serverErrors()['code'];
  }

  protected loginBad(): boolean {
    return this.bad(this.form.controls.owner.controls.login) || !!this.serverErrors()['login'];
  }

  protected openAdd(): void {
    this.form.reset();
    this.form.controls.owner.controls.password.setValue(generatePassword());
    this.tried.set(false);
    this.serverErrors.set({});
    this.formOpen.set(true);
  }

  protected generate(): void {
    this.form.controls.owner.controls.password.setValue(generatePassword());
  }

  protected save(): void {
    this.tried.set(true);
    if (this.form.invalid) {
      this.notify.error('common.requiredTitle', 'platform.orgs.required');
      return;
    }
    const v = this.form.getRawValue();
    const draft = {
      code: v.code.trim(),
      name: v.name.trim(),
      owner: {
        name: v.owner.name.trim(),
        login: v.owner.login.trim(),
        password: v.owner.password,
        phone: v.owner.phone.trim(),
      },
      hotel: hotelDraft(this.form.controls.hotel),
    };
    this.saving.set(true);
    this.api.createOrganization(draft).subscribe({
      next: (org) => {
        this.saving.set(false);
        this.formOpen.set(false);
        this.rows.update((l) => [...l, org]);
        this.handoverName.set(org.name);
        this.handover.set([
          { label: 'platform.handover.link', value: organizationUrl(org.code) },
          { label: 'platform.owner.login', value: draft.owner.login, mono: true },
          { label: 'platform.owner.password', value: draft.owner.password, mono: true },
        ]);
        this.handoverOpen.set(true);
      },
      error: (e: unknown) => {
        this.saving.set(false);
        const code = e instanceof ApiError ? e.code : 'common.unknown';
        const fields = e instanceof ApiError ? e.fields : {};
        const errs: Record<string, string> = {};
        if (code === 'organizations.exists') {
          errs['code'] = 'exists';
        } else if (fields['code']) {
          errs['code'] = 'invalid';
        }
        if (code === 'users.loginTaken') {
          errs['login'] = 'taken';
        }
        if (code === 'settings.innInvalid' || fields['hotel.inn'] || fields['inn']) {
          errs['inn'] = 'invalid';
        }
        this.serverErrors.set(errs);
        this.notify.error('common.saveError', `errors.${code}`);
      },
    });
  }

  // ----- Передать владельцу -----
  protected readonly handoverOpen = signal(false);
  protected readonly handoverName = signal('');
  protected readonly handover = signal<CredentialRow[]>([]);

  protected open(o: Organization | null): void {
    if (o) {
      void this.router.navigate(['/platform/organizations', o.id]);
    }
  }
}
